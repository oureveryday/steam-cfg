Copy both files to the main game folder (replace files).
Add '_1' to the name of the folders of DLCs you want to unlock.

ie: 'dlc_148' must be renamed to 'dlc_148_1'







Thanks @ acidicoala
All credit for the unlocker goes to Mr_Goldberg. Since he released the source of his Uplay R2 emulator, I did not have to spend time reverse engineering R2 API.
I want to thank sam2k8 for letting me know about the R2 source and the idea of the DLC unlocker. Furthermore, sam2k8 has helped with testing the version 3 with number of different games, for which I am truly grateful.
Credit to machine4578 for testing the version 3 of the unlocker.
I would also like to thank asqwed for helping test the unlocker with Anno 1800, as well as for posting a config file with comments describing each ID.
Finally, I want to express my sincere gratitude to Christsnatcher for agreeing to help maintain the online config and keep it up-to-date.

SOURCE:
https://cs.rin.ru/forum/viewtopic.php?f=10&t=111874
https://github.com/acidicoala/UplayR2Unlocker